<?php
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        header("Location: ../register.php?error=" . urlencode("Semua field harus diisi."));
        exit;
    }

    if ($password !== $confirm_password) {
        header("Location: ../register.php?error=" . urlencode("Password dan konfirmasi tidak sama."));
        exit;
    }

    $checkQuery = "SELECT id FROM users WHERE username = $1";
    $checkResult = pg_query_params($conn, $checkQuery, [$username]);

    if (!$checkResult) {
        header("Location: ../register.php?error=" . urlencode("Gagal memeriksa username."));
        exit;
    }

    if (pg_num_rows($checkResult) > 0) {
        header("Location: ../register.php?error=" . urlencode("Username sudah digunakan."));
        exit;
    }

    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $insertQuery = "INSERT INTO users (username, email, password, role) VALUES ($1, $2, $3, $4)";
    $insertResult = pg_query_params($conn, $insertQuery, [$username, $email, $password_hash, 'user']);

    if ($insertResult) {
        header("Location: ../login.php?success=1");
        exit;
    } else {
        header("Location: ../register.php?error=" . urlencode("Terjadi kesalahan saat menyimpan data."));
        exit;
    }
}