<?php
session_start();
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        echo "Username dan password tidak boleh kosong.";
        exit;
    }

    $query = "SELECT id, username, password, role FROM users WHERE username = $1";
    $result = pg_query_params($conn, $query, [$username]);

    if (!$result) {
        echo "Terjadi kesalahan saat mengakses database.";
        exit;
    }

    if (pg_num_rows($result) === 0) {
        echo "Username tidak ditemukan.";
        exit;
    }

    $user = pg_fetch_assoc($result);

    if (!password_verify($password, $user['password'])) {
        echo "Password salah.";
        exit;
    }

    session_regenerate_id(true);

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];

    header("Location: ../dashboard.php");
    exit;
} else {
    echo "Akses tidak valid.";
}
