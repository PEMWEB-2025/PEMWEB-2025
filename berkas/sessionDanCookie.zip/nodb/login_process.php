<?php
session_start(); // Memulai Session

// Untuk memudahkan jika postgre tidak bisa dijalankan
$users = [
    'admin' => [
        'username' => 'admin',
        'password' => 'admin123',
        'role' => 'admin'
    ],
    'user' => [
        'username' => 'user',
        'password' => 'user123',
        'role' => 'user'
    ]
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        echo "Username dan password tidak boleh kosong.";
        exit;
    }

    if (isset($users[$username]) && $users[$username]['password'] === $password) {

        session_regenerate_id(true); // regenerate session jika login

        $_SESSION['user_id'] = $username;               //
        $_SESSION['username'] = $username;              // set value untuk session
        $_SESSION['role'] = $users[$username]['role'];  //

        header("Location: ../dashboard.php");
        exit;
    } else {
        echo "Username atau password salah.";
        exit;
    }
} else {
    echo "Akses tidak valid.";
}
