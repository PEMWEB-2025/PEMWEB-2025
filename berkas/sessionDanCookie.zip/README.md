# Demo Praktikum

## Menggunakan Postgresql

untuk memulai, run
`docker-compose up`, lalu masuk ke pgadmin dengan email dan password seperti berikut :

```
EMAIL       : admin@example.com
PASSWORD    : adminpassword
```

Lalu sambungkan database dengan detail berikut :

```
host        = host.docker.internal
port        = 5432
dbname      = pemweb
user        = myuser
password    = mypassword!
```

jika sudah buat tabel baru pada skema public bernama users seperti sql berikut :

```sql
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role VARCHAR(20) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

jika sudah jalankan php menggunakan `php -S localhost:8000` atau gunakan server development kalian (xampp, laragon, etc)

## Tidak menggunakan DB

Jalankan saja seperti biasa, dengan keterbatasan tidak bisa register, dan hanya bisa login dengan route `loginnodb.php`, berikut username dan password yang bisa digunakan :

```
    'username' => 'admin',
    'password' => 'admin123',
    'role' => 'admin'

    'username' => 'user',
    'password' => 'user123',
    'role' => 'user'
```

## Penjelasan dan Praktek

### 1. Pembuatan Session Baru

pada file `login_process.php`, terdapat pembuatan session baru dan set value value berdasarkan hasil query.
```
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
```

### 2. Menggunakan Variable Pada Session

pada file `dashboard.php`, diambil variable-variable session yang sudah di-set pada login proses tadi untuk digunakan.
```
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    $isAdmin = $role === 'admin';
```

### 3. Di Mana Cookie Tersimpan?
1. `Press F12` atau  `inspect element` pada browser, 
2. setelah itu pilih menu `storage` lalu `cookies`
3. di sana seharusnya terdapat cookies bernama `PHPSESSID` setelah melakukan login
4. Cookie ini digunakan sebagai pengenal pada session

### 4. Di Mana Session Tersimpan?
Pada route `dashboard.php` terdapat informasi dimana letak session disimpan sementara, informasi diperoleh dari :
```
ini_get('session.save_path');
```

Akses folder tersebut lalu buka salah satu file session, apa yang anda lihat?